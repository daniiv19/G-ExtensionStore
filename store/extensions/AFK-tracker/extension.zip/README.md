# anti-afk
Anti AFK. An extension that tracks how long you have been AFK.
    - Also keeps track of Hours/Days.
