This extension tracks how long you have been AFK for. It updates every 5 minutes and shouts in the room. 
Also keeps track of hours and days of AFK, in case you forget to turn off your pc :p.